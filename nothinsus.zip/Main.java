import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    Scanner input=new Scanner(System.in);
    System.out.println("enter the number of women youve pulled:");
    int num=input.nextInt();
    System.out.println("You have pulled "+num+" women!");
  }
}